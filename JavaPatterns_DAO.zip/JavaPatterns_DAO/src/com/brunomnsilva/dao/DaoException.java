package com.brunomnsilva.dao;

/**
 * @author brunomnsilva
 */
public class DaoException extends RuntimeException {
    public DaoException(String s) {
        super(s);
    }
}
