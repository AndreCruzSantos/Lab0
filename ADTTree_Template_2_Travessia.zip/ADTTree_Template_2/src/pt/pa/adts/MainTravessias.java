package pt.pa.adts;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class MainTravessias {
    public static void main(String[] args) {
        Tree<String> tree = new TreeLinked<>("a");
        Position<String> root = tree.root();

        Position<String> b = tree.insert(root, "b");
        Position<String> c = tree.insert(root, "c");
        Position<String> d = tree.insert(b, "d");
        Position<String> e = tree.insert(c, "e");
        Position<String> f = tree.insert(c, "f");
        Position<String> g = tree.insert(d, "g");
        Position<String> h = tree.insert(f, "h");
        Position<String> i = tree.insert(f, "i");
        Position<String> j = tree.insert(f, "j");
        Position<String> k = tree.insert(g, "k");
        Position<String> l = tree.insert(g, "l");

        System.out.println(tree);

        System.out.println("BFS ----------");
        BFS(tree);
        System.out.println("DFS ----------");
        DFS(tree);
    }

    public static <V> void BFS(Tree<V> tree) {
        Queue<Position<V>> queue = new LinkedList<>();

        queue.offer( tree.root() ); //enqueue
        while(!queue.isEmpty()) {
            Position<V> n = queue.poll(); //dequeue
            /* Processar nó */
            System.out.println(n.element());
            for(Position<V> f : tree.children(n)) {
                queue.offer(f);
            }
        }
    }

    public static <V> void DFS(Tree<V> tree) {
        Stack<Position<V>> queue = new Stack<>();

        queue.push( tree.root() ); //enqueue
        while(!queue.isEmpty()) {
            Position<V> n = queue.pop(); //dequeue
            /* Processar nó */
            System.out.println(n.element());
            for(Position<V> f : tree.children(n)) {
                queue.push(f);
            }
        }
    }
}
