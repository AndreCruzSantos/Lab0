package com.pa.strategy.solutionStrategy;
/*
 *@author patriciamacedo
 */
import java.util.*;

public class StrategyMultiSkill implements Strategy {

    /**
     *
     * @param personList - List of persons in the group
     * @return ratio between person that domain more than 5 languages and group size
     */
    @Override
    public float calculateGlobalIndex(Map<Integer, Programmer> personList){
        int countL=0;
        for (Programmer programmer : personList.values()) {
            if( programmer.getNumberLanguages()>5)
                countL++;
        }
        return countL*1.f/personList.size();
    }

    @Override
    public Programmer selectLeader(Map<Integer, Programmer> personList) {
        if(personList.isEmpty()) return null;

        List<Programmer> programmers = new ArrayList<>(personList.values());
        Collections.sort(programmers, new Comparator<Programmer>() {
            @Override
            public int compare(Programmer p1, Programmer p2) {
                /* devolver > 0 se p1 tem mais linguagens programacao que p2 */
                /*
                if(p1.getNumberLanguages() == p2.getNumberLanguages()) {
                    return p1.getYearsOfExperience() - p2.getYearsOfExperience();
                } else
                    return p1.getNumberLanguages() - p2.getNumberLanguages();
                 */

                if(p1.getNumberLanguages() == p2.getNumberLanguages()) {
                    return (p1.getYearsOfExperience() < p2.getYearsOfExperience() ? 1 : -1);
                } else
                return (p1.getNumberLanguages() > p2.getNumberLanguages() ? 1 : -1);

            }
        });

        return programmers.get(programmers.size() - 1);
    }

}
