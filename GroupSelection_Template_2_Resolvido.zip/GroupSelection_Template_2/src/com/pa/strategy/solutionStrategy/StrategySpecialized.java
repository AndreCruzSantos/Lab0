package com.pa.strategy.solutionStrategy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class StrategySpecialized implements Strategy {
    @Override
    public float calculateGlobalIndex(Map<Integer, Programmer> personList) {
        float y = personList.size();
        int x = 0;
        for(Programmer p : personList.values()) {
            if(p.getYearsOfExperience() >= 5 && p.getNumberLanguages() <= 3) x++;
        }
        return x / (y-x); /* cuidado com a divisao inteira, e.g., 5/6 -> 0! */
    }

    @Override
    public Programmer selectLeader(Map<Integer, Programmer> personList) {
        if(personList.isEmpty()) return null;
        Random rand = new Random();
        List<Programmer> programmers = new ArrayList<>(personList.values());
        Programmer leader = programmers.get(0);
        for (int i=1; i< programmers.size(); i++) {
            Programmer p = programmers.get(i);
            if(p.getYearsOfExperience() >=5 && p.getNumberLanguages() < leader.getNumberLanguages()) {
                leader = p;
            } else if(p.getYearsOfExperience() >=5 && p.getNumberLanguages() == leader.getNumberLanguages()){
                leader = rand.nextBoolean() ? leader : p;
            }
        }
        return leader;
    }
}
